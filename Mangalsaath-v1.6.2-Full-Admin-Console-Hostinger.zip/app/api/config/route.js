import { NextResponse } from "next/server";
import { readDb } from "@/lib/db";
export async function GET(){
  const db=await readDb(); const s=db.settings||{};
  return NextResponse.json({
    businessName:s.businessName,businessAddress:s.businessAddress,gstin:s.gstin,
    supportEmail:s.supportEmail,supportMobile:s.supportMobile,whatsapp:s.whatsapp,
    footerCopyright:s.footerCopyright,maintenanceMode:!!s.maintenanceMode,registrationEnabled:s.registrationEnabled!==false
  },{headers:{"Cache-Control":"no-store"}});
}
