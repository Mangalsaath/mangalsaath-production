import { NextResponse } from "next/server";
import { readDb, writeDb, getUser, uid } from "@/lib/db";

export async function GET(request){
 const user=await getUser(request); if(!user)return NextResponse.json({error:"Unauthorized"},{status:401});
 const db=await readDb(); const profile=db.profiles.find(p=>p.userId===user.id); if(!profile)return NextResponse.json({error:"Profile not found."},{status:404});
 const history=(db.verificationAudits||[]).filter(a=>a.profileId===profile.id).sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt));
 return NextResponse.json({verification:{status:profile.verificationStatus||"not-requested",documentType:profile.verificationDocumentType||"",documentLast4:profile.verificationDocumentLast4||"",note:profile.verificationNote||"",requestedAt:profile.verificationRequestedAt||null,reviewedAt:profile.verificationReviewedAt||null,trusted:Boolean(profile.trustedProfile)},history});
}

export async function POST(request){
 const user=await getUser(request); if(!user)return NextResponse.json({error:"Unauthorized"},{status:401});
 const body=await request.json().catch(()=>({}));
 const documentType=String(body.documentType||"").trim(); const documentLast4=String(body.documentLast4||"").replace(/\D/g,"").slice(-4);
 if(!["Aadhaar","Passport","Driving Licence","Voter ID"].includes(documentType))return NextResponse.json({error:"Select a valid identity document type."},{status:400});
 if(documentLast4.length!==4)return NextResponse.json({error:"Enter the last 4 digits/characters of the document number."},{status:400});
 const db=await readDb(); const index=db.profiles.findIndex(p=>p.userId===user.id); if(index<0)return NextResponse.json({error:"Profile not found."},{status:404});
 const profile=db.profiles[index];
 const fields=["name","gender","dateOfBirth","maritalStatus","height","religion","caste","education","profession","country","state","city","about"];
 const completion=Math.round(fields.filter(k=>String(profile[k]||"").trim()).length/fields.length*100);
 if(completion<80)return NextResponse.json({error:"Please complete at least 80% of your profile before requesting verification."},{status:400});
 if(profile.verificationStatus==="requested")return NextResponse.json({error:"Verification is already under review."},{status:409});
 if(profile.verified||profile.verificationStatus==="approved")return NextResponse.json({error:"Profile is already verified."},{status:409});
 const now=new Date().toISOString();
 Object.assign(profile,{verificationStatus:"requested",verificationRequestedAt:now,verificationReviewedAt:null,verificationReviewedBy:null,verificationNote:"",verificationDocumentType:documentType,verificationDocumentLast4:documentLast4,trustedProfile:false});
 db.verificationAudits=db.verificationAudits||[];
 db.verificationAudits.unshift({id:uid("va"),profileId:profile.id,userId:user.id,actorUserId:user.id,action:"requested",note:`${documentType} ending ${documentLast4}`,createdAt:now});
 db.activities=db.activities||[]; db.activities.unshift({id:uid("a"),type:"verification_requested",userId:user.id,profileId:profile.id,description:`${profile.name} requested identity verification`,createdAt:now});
 await writeDb(db); return NextResponse.json({message:"Identity verification request submitted for admin review.",status:"requested"});
}
