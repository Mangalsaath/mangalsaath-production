import { NextResponse } from "next/server";
import { readDb } from "@/lib/db";
import { getVisibleOffers } from "@/lib/offers";

export async function GET(){
  const db=await readDb();
  const now=new Date();
  const offers=getVisibleOffers(db,now);
  const today=now.toISOString().slice(0,10);
  const stats={
    totalVisitors:Number(db.analytics?.uniqueVisitors||0),
    totalVisits:Number(db.analytics?.totalVisits||0),
    todayVisitors:Number(db.analytics?.daily?.[today]?.uniqueVisitors||0),
    registeredMembers:(db.users||[]).filter(u=>u.role!=="admin").length,
    verifiedProfiles:(db.profiles||[]).filter(p=>p.trustedProfile||p.verified).length,
    premiumMembers:(db.users||[]).filter(u=>!["free",""].includes(String(u.membershipPlanId||"free").toLowerCase())).length
  };
  return NextResponse.json({offers,primaryOffer:offers[0]||null,stats},{headers:{"Cache-Control":"no-store"}});
}
